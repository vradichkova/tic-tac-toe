
let turnCount = 0;
let lastTurn = '';
let gameOver = false;
const classX = 'blue';
const classO = 'orange';
const boxes = document.querySelectorAll('.box');
const btnReplay = document.querySelector('#replay');
const errorMsg = document.querySelector('.error');
const successMsg = document.querySelector('.success');
const alert = document.querySelector('.alert');
const msgTimeout = 2000;
const winningCombos = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

initBoard();
loadEventListeners();

function loadEventListeners() {
    boxes.forEach(box => box.addEventListener('click', validateInput));
    btnReplay.addEventListener('click', initGame);
    alert.addEventListener('click', hideMessage);
}

function initBoard() {
    for (let i = 0; i < boxes.length; i++) {
        boxes[i].setAttribute('id', i);
    }
}

function addClass(e) {
    if (e.target.innerText === 'o' && !e.target.classList.contains(classO)) {
        return classO;
    } else if ((e.target.innerText === 'x' && !e.target.classList.contains(classX))) {
        return classX;
    }
}

function getNextTurn() {
    if (turnCount === 0 || turnCount % 2 === 0) {
        return 'o';
    }
    return 'x';
}

function checkWinner() {
    for (combo of winningCombos) {
        if (boxes[combo[0]].innerText !== '' &&
            boxes[combo[0]].innerText === boxes[combo[1]].innerText &&
            boxes[combo[0]].innerText === boxes[combo[2]].innerText) {

            return true;
        }
    }
    return false;
}

function deleteMessageContent() {
    alert.innerHTML = "";
}

function hideMessage(e) {
    if (e.target.className === "close") {
        deleteMessageContent();
    }
}

function showMessage(msg, className) {
    deleteMessageContent();
    const message = document.createElement('div');
    message.className = className;
    message.innerHTML = `${msg} <a href="#" class="close">x</a>`;
    alert.appendChild(message);
}

function initGame() {
    turnCount = 0;
    gameOver = false;
    lastTurn = '';
    boxes.forEach(box => {
        box.innerText = '';
        if (box.classList.contains(classX)) {
            box.classList.remove(classX);
        }
        if (box.classList.contains(classO)) {
            box.classList.remove(classO);
        }
    });
    deleteMessageContent();
}

function validateInput(e) {
    if (gameOver) {
        showMessage('Game over', 'error');
        return;
    }

    if (e.target.innerText !== '') {
        showMessage('This box is filled. <br>Click on an empty one.', 'error');
        return;
    }

    turnCount++;
    e.target.innerText = getNextTurn();
    lastTurn = e.target.innerText;
    e.target.classList.add(addClass(e));

    if (checkWinner()) {
        gameOver = true;
        showMessage(`Player ${lastTurn.toUpperCase()} won!`, 'success');
        return;
    }

    if (turnCount === 9) {
        gameOver = true;
        showMessage('Game over. No winners.', 'error');
        return;
    }
}
